const mybull = require("../utility/mybull");
new mybull("test")