const mysql = require('mysql2');
const sql = require('./db.model');

const Chanel = ()=>{
}

Chanel.getall_chanels = (callback)=>{

    callback("All chanels.")

}


module.exports = Chanel;